## 介绍
ZYPlayer是一款基于electron开发的一款播放器，能一键搜索全网影视,支持自定义直播、点播源. 安卓+Pc双端!!!

## 下载
### [蓝奏云](http://https://sharerw.lanzous.com/b0aewem6j#wau8)

### 点播源在线导入地址
#### https://gitee.com/gyhxx/freedtv/raw/master/zy/dianbo.json
### 直播源在线导入地址
#### https://gitee.com/gyhxx/freedtv/raw/master/zy/zhibo.m3u

## Pc版本可下载到本地再导入!