# FreedDTV————ZYPlayer————红影TV
![](https://gitee.com/gyhxx/pic/raw/master/freedtv/1.png "")

![](https://gitee.com/gyhxx/pic/raw/master/freedtv/2.png "")
#### 介绍
Free DTV 外链接口

[Free DTV DownLoad](https://www.lanzoui.com/b025mpw7e)

#### 使用说明
打开软件---自建接口,输入以下地址:

https://gitee.com/gyhxx/freedtv/raw/master/

## 注意别漏掉最后的斜杠!!!!!!
